import asjava.uniobjects.*;

public class App {

    private static final UniJava uJava = new UniJava();

    private static String ExecuteCommand(final String server, final String user, final String password,
            final String account, final String command) {
        try {

            UniJava.setMinPoolSize(0);
            UniJava.setMaxPoolSize(10);
            UniJava.setUOPooling(true);

            UniSession uSession = null;

            try {
                uSession = uJava.openSession();
                uSession.connect(server, user, password, account);
                final UniCommand uvc = uSession.command();
                uvc.setCommand(command);
                uvc.exec();
                return uvc.response();
            } 
			catch(Exception e){
				return "Error while connecting to Unidata";
			}
			finally {
                if (uSession != null) {
                    uSession.disconnect();
                }
            }

        } catch (final Exception ex) {
            return "Error while connecting to Unidata";
        }
    }

    public static void main(final String args[]) {
		testSampleData();
    }
	
	public static String getUniqueryOutput(String server, String user, String password,String account, String command){
		return ExecuteCommand(server, user, password,account, command);
	}
	
	public static String testSampleData(){
		System.out.print("in testSampleData");
		return "Sample Data from testSampleData";
	}
}